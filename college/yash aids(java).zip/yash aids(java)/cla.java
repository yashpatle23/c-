public class cla {
    public static void main(String args[]){
        System.out.print("enter the ");
        System.out.print(args[0]);
    }
}
